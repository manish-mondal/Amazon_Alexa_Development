ASK SDK Model package contains the type definition and service clients classes for Alexa Skills Kit (ASK) Software Development Kit (SDK) for Node.js. Please refer to the [main SDK repository](https://github.com/alexa/alexa-skills-kit-sdk-for-nodejs) for guidance on gettings started with the ASK SDK for Node.js.

